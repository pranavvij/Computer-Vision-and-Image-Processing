import cv2
import numpy as np
from random import shuffle
print(cv2.__version__)

def show(img, name):
    cv2.imwrite('imgs/' + name + '.png', img)
    cv2.waitKey(0)


def get_keypoints(img):
    gray= cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sift = cv2.xfeatures2d.SIFT_create()
    kp, des = sift.detectAndCompute(gray,None)
    img_kp = cv2.drawKeypoints(gray, kp, None, color = (128, 0, 128))
    return img_kp, des, kp

def match_using_knn(des_1, des_2, k = 2):
    bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
    rawMatches = bf.knnMatch(des_1, des_2, 2)
    good = []
    for m,n in rawMatches:
        if m.distance < 0.75*n.distance:
            good.append(m)
    task1_matches_knn = cv2.drawMatches(mountain_1, kp_1 ,mountain_2, kp_2, good, None, flags=2)
    return task1_matches_knn, good

mountain_1 = cv2.imread('imgs/mountain1.jpg')
mountain_2 = cv2.imread('imgs/mountain2.jpg')

task1_sift1, des_1, kp_1 = get_keypoints(mountain_1)
task1_sift2, des_2, kp_2 = get_keypoints(mountain_2)

show(task1_sift1, 'task1_sift1')
show(task1_sift2, 'task1_sift2')

task1_matches_knn, good = match_using_knn(des_1, des_2, 2)
show(task1_matches_knn, 'task1_matches_knn')

src_pts = np.float32([ kp_1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
dst_pts = np.float32([ kp_2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)
M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)
matchesMask = mask.ravel().tolist()

print(M)

inliers = []

for x in range(len(matchesMask)):
    if matchesMask[x] == 1:
        inliers.append(x)

shuffle(inliers)

if len(inliers) > 10:
    inliers = inliers[0:10]


task1_matches_inliers = cv2.drawMatches(mountain_1, kp_1 ,mountain_2, kp_2, [good[inlier] for inlier in inliers], None, flags=2)
show(task1_matches_inliers, 'task1_matches_inliers')

stitcher = cv2.createStitcher(False)
status, result = stitcher.stitch((mountain_1, mountain_2))

print(result)
show(result[1], 'stitcher')
