import numpy as np
from sklearn.cluster import KMeans
from collections import defaultdict
import math
import cv2
import matplotlib
matplotlib.use('PS')
import matplotlib.pyplot as plt

class KMeans:
    def __init__(self, k, init_center):
        self.k = k
        self.centroids = init_center
        self.clustering = []

    def euclidean_distance(self, X, Y):
        tmp = X - Y
        sum_squared = np.linalg.norm(tmp)
        return sum_squared

    def assign_min_eu(self, x):
        min_eu = self.euclidean_distance(self.centroids[0], x)
        min_index = 0
        for i in range(1, self.k):
            eu = self.euclidean_distance(self.centroids[i], x)
            if min_eu > eu:
                min_index = i
                min_eu = eu
        self.clustering.append(min_index)

    def update_centroid(self, X):
        self.centroids = np.zeros((self.k, X.shape[1]))
        self.cluster_count = defaultdict(lambda: 0)

        for i in range(0, X.shape[0]):
            self.centroids[self.clustering[i]] += X[i]
            self.cluster_count[self.clustering[i]] += 1

        for i in range(0, self.k):
            self.centroids[i] /= self.cluster_count[i]

    def fit(self, X, EPOCHS):
        for epoch in range(EPOCHS):
            self.clustering = []
            for x in X:self.assign_min_eu(x)
            self.update_centroid(X)
        return self.centroids

X = [
[5.9, 3.2],
[4.6, 2.9],
[6.2, 2.8],
[4.7, 3.2],
[5.5, 4.2],
[5.0, 3.0],
[4.9, 3.1],
[6.7, 3.1],
[5.1, 3.8],
[6.0, 3.0]
]

init_center = [
[6.5, 3.0],
[6.6, 3.7],
[6.2, 3.2]
]

X = np.asarray(X)
init_center = np.asarray(init_center)

k = KMeans(3, init_center)
k.fit(X, 2)

print(k.clustering)

plt.scatter(X[:, 0], X[:, 1], c=k.clustering,s=50, cmap='viridis');
plt.show()
