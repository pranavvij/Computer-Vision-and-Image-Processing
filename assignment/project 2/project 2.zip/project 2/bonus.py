import numpy as np
import pandas as pd
import random as rand
import matplotlib
matplotlib.use('PS')
import matplotlib.pyplot as plt
from scipy.stats import norm
from sys import maxsize

### Setup
# set random seed
rand.seed(42)

X = [
        [5.9, 3.2],
        [4.6, 2.9],
        [6.2, 2.8],
        [4.7, 3.2],
        [5.5, 4.2],
        [5.0, 3.0],
        [4.9, 3.1],
        [6.7, 3.1],
        [5.1, 3.8],
        [6.0, 3.0]
    ]

mu = [
        [6.2, 6.2],
        [6.6, 6.6],
        [6.5, 6.5]
    ]

SIGMA = [
            [[0.5, 0],[0, 0.5]],
            [[0.5, 0],[0, 0.5]],
            [[0.5, 0],[0, 0.5]]
        ]

PIE = [1/3,1/3,1/3]

# 2 clusters
# not that both covariance matrices are diagonal
mu1 = mu[0]
sig1 = SIGMA[0]

mu2 = mu[1]
sig2 = SIGMA[1]

mu3 = mu[2]
sig3 = SIGMA[2]

# generate samples
x1, y1 = np.random.multivariate_normal(mu1, sig1, 100).T
x2, y2 = np.random.multivariate_normal(mu2, sig2, 100).T
x3, y3 = np.random.multivariate_normal(mu3, sig3, 100).T

xs = np.concatenate((x1, x2, x3))
ys = np.concatenate((y1, y2, y3))

labels = ([1] * 100) + ([2] * 100) + ([3]*100)

data = {'x': xs, 'y': ys, 'label': labels}
df = pd.DataFrame(data=data)

# inspect the data
df.head()
df.tail()

fig = plt.figure()
plt.scatter(data['x'], data['y'], 24, c=data['label'])
fig.savefig("true-values.png")

### Expectation-maximization

# initial guesses - intentionally bad
guess = {
          'mu1': mu1,
          'sig1': sig1,
          'lambda1': PIE[0],
          'mu2': mu2,
          'sig2': sig2,
          'lambda2': PIE[1],
          'mu3': mu3,
          'sig3': sig3,
          'lambda3': PIE[2]
        }

# probability that a point came from a Guassian with given parameters
# note that the covariance must be diagonal for this to work
def prob(val, mu, sig, lam):
  p = lam
  for i in range(len(val)):
    p *= norm.pdf(val[i], mu[i], sig[i][i])
  return p


# assign every data point to its most likely cluster
def expectation(dataFrame, parameters):
  for i in range(dataFrame.shape[0]):
    x = dataFrame['x'][i]
    y = dataFrame['y'][i]
    p_cluster1 = prob([x, y], list(parameters['mu1']), list(parameters['sig1']), parameters['lambda1'])
    p_cluster2 = prob([x, y], list(parameters['mu2']), list(parameters['sig2']), parameters['lambda2'])
    p_cluster3 = prob([x, y], list(parameters['mu3']), list(parameters['sig3']), parameters['lambda3'])

    p = max([p_cluster1[0], p_cluster2[0], p_cluster3[0]])
    if p == p_cluster1[0]:
      dataFrame['label'][i] = 1
    elif p == p_cluster2[0]:
      dataFrame['label'][i] = 2
    else:
      dataFrame['label'][i] = 3
  return dataFrame


# update estimates of lambda, mu and sigma
def maximization(dataFrame, parameters):
  points_assigned_to_cluster1 = dataFrame[dataFrame['label'] == 1]
  points_assigned_to_cluster2 = dataFrame[dataFrame['label'] == 2]
  points_assigned_to_cluster3 = dataFrame[dataFrame['label'] == 3]

  percent_assigned_to_cluster1 = len(points_assigned_to_cluster1) / float(len(dataFrame))
  percent_assigned_to_cluster2 = len(points_assigned_to_cluster2) / float(len(dataFrame))
  percent_assigned_to_cluster3 = len(points_assigned_to_cluster3) / float(len(dataFrame))

  parameters['lambda'] = [percent_assigned_to_cluster1, percent_assigned_to_cluster2, percent_assigned_to_cluster3 ]
  parameters['mu1'] = [points_assigned_to_cluster1['x'].mean(), points_assigned_to_cluster1['y'].mean()]
  parameters['mu2'] = [points_assigned_to_cluster2['x'].mean(), points_assigned_to_cluster2['y'].mean()]
  parameters['mu3'] = [points_assigned_to_cluster3['x'].mean(), points_assigned_to_cluster3['y'].mean()]

  parameters['sig1'] = [ [points_assigned_to_cluster1['x'].std(), 0 ], [ 0, points_assigned_to_cluster1['y'].std() ] ]
  parameters['sig2'] = [ [points_assigned_to_cluster2['x'].std(), 0 ], [ 0, points_assigned_to_cluster2['y'].std() ] ]
  parameters['sig3'] = [ [points_assigned_to_cluster3['x'].std(), 0 ], [ 0, points_assigned_to_cluster3['y'].std() ] ]
  return parameters

# get the distance between points
# used for determining if params have converged
def distance(old_params, new_params):
  dist = 0
  for param in ['mu1', 'mu2','mu3']:
    for i in range(len(old_params)):
      dist += (old_params[param][i] - new_params[param][i]) ** 2
  return dist ** 0.5

# loop until parameters converge
shift = maxsize
epsilon = 0.01
iters = 0
df_copy = df.copy()

# randomly assign points to their initial clusters
df_copy['label'] = map(lambda x: x+1, np.random.choice(2, len(df)))
params = pd.DataFrame(guess)

while shift > epsilon:
  iters += 1
  # E-step
  updated_labels = expectation(df_copy.copy(), params)

  # M-step
  updated_parameters = maximization(updated_labels, params.copy())

  # see if our estimates of mu have changed
  # could incorporate all params, or overall log-likelihood
  shift = distance(params, updated_parameters)

  # logging
  print("iteration {}, shift {}".format(iters, shift))

  # update labels and params for the next iteration
  df_copy = updated_labels
  params = updated_parameters

  fig = plt.figure()
  plt.scatter(df_copy['x'], df_copy['y'], 24, c=df_copy['label'])
  fig.savefig("imgs/iteration{}.png".format(iters))
