import cv2
import numpy as np
from random import shuffle

print(cv2.__version__)
def normalize_matrix(A):
	row_a_size = len(A)
	col_a_size = len(A[0])
	max_x = 0
	min_x = A[0][0]
	for i in range(0, row_a_size):
		max_x = max(max(A[i]), max_x)
		min_x = min(min(A[i]), min_x)
	for i in range(0, row_a_size):
		for j in range(0, col_a_size):
			A[i][j] = 255 * ((max_x - A[i][j])/(max_x - min_x))
	return A

def show(img, name=""):
    cv2.imwrite('imgs/' + name + '.jpg', img)
    cv2.waitKey(0)

def get_keypoints(img):
    gray= cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sift = cv2.xfeatures2d.SIFT_create()
    kp, des = sift.detectAndCompute(gray,None)
    img_kp = cv2.drawKeypoints(gray, kp, None, color = (128, 0, 128))
    return img_kp, des, kp

def drawlines(img1,img2,lines,pts1,pts2):
    r,c = img1.shape
    img1 = cv2.cvtColor(img1,cv2.COLOR_GRAY2BGR)
    img2 = cv2.cvtColor(img2,cv2.COLOR_GRAY2BGR)
    for r,pt1,pt2 in zip(lines,pts1,pts2):
        color = tuple(np.random.randint(0,255,3).tolist())
        x0,y0 = map(int, [0, -r[2]/r[1] ])
        x1,y1 = map(int, [c, -(r[2]+r[0]*c)/r[1] ])
        img1 = cv2.line(img1, (x0,y0), (x1,y1), color,1)
        img1 = cv2.circle(img1,tuple(pt1),5,color,-1)
        img2 = cv2.circle(img2,tuple(pt2),5,color,-1)
    return img1,img2


def match_using_knn(des_1, des_2, k, kp_1, kp_2):
    bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
    rawMatches = bf.knnMatch(des_1, des_2, 2)
    good = []
    pts1 = []
    pts2 = []
    for m,n in rawMatches:
        if m.distance < 0.75*n.distance:
            good.append(m)
            pts2.append(kp_2[m.trainIdx].pt)
            pts1.append(kp_1[m.queryIdx].pt)

    task1_matches_knn = cv2.drawMatches(mountain_1, kp_1 ,mountain_2, kp_2, good, None, flags=2)
    return task1_matches_knn, good, pts1, pts2

mountain_1 = cv2.imread('imgs/tsucuba_left.png')
mountain_2 = cv2.imread('imgs/tsucuba_right.png')

task1_sift1, des_1, kp_1 = get_keypoints(mountain_1)
task1_sift2, des_2, kp_2 = get_keypoints(mountain_2)

# show(task1_sift1, 'task1_sift1')
# show(task1_sift2, 'task1_sift2')

task1_matches_knn, good, pts1, pts2 = match_using_knn(des_1, des_2, 2, kp_1, kp_2)
# show(task1_matches_knn, 'task1_matches_knn')

pts1 = np.int32(pts1)
pts2 = np.int32(pts2)
F, mask = cv2.findFundamentalMat(pts1,pts2, cv2.FM_LMEDS)
print(F)

mountain_1 = cv2.imread('imgs/tsucuba_left.png', 0)
mountain_2 = cv2.imread('imgs/tsucuba_right.png', 0)
#
# show(mountain_1)
# show(mountain_2)

lines1 = cv2.computeCorrespondEpilines(pts2[:10].reshape(-1,1,2), 2,F)
lines1 = lines1.reshape(-1,3)
img5,img6 = drawlines(mountain_1 ,mountain_2,lines1,pts1,pts2)

show(img5, 'Task2_epi_right')
# show(img6, 'img6')

# Find epilines corresponding to points in left image (first image) and
# drawing its lines on right image
lines2 = cv2.computeCorrespondEpilines(pts1[:10].reshape(-1,1,2), 1,F)
lines2 = lines2.reshape(-1,3)
img3, img4 = drawlines(mountain_2,mountain_1,lines2, pts2, pts1)

show(img3, 'Task2_epi_left')
# show(img4, 'img4')

stereo = cv2.StereoBM_create(numDisparities=48, blockSize=15)
disparity = stereo.compute(mountain_1,mountain_2)
show(normalize_matrix(disparity), 'tsucuba_right')

stereo = cv2.StereoBM_create(numDisparities=48, blockSize=15)
disparity = stereo.compute(mountain_2,mountain_1)
show(normalize_matrix(disparity), 'tsucuba_left')
